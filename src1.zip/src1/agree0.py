# Compares strings

answer = input("Do you agree? ")
if answer == "yes":
    print("Agreed")
else:
    print("Not agreed")
